const bcrypt = require("bcrypt");

const User = require("../models/user.model");
const jwt = require("jsonwebtoken");

class AuthService {
  signup = async (payload) =>
    await new User({
      ...payload,
      password: await this.generatePasswordHash(payload.password),
    }).save();

  generatePasswordHash = (plainTextPassword) =>
    bcrypt.hash(plainTextPassword, 10);

  login = async ({ username, password }) => {
    const reqUser = await User.findOne({ username });
    if (!reqUser) {
      throw new Error("UserNotFound");
    }
    const isLoggedIn = await this.verifyPassword(password, reqUser.password);
    if (isLoggedIn) {
      return {
        isLoggedIn,
        token: this.generateJwt({ userId: reqUser._id }),
      };
    }
    return { isLoggedIn };
  };

  verifyPassword = async (passwordPlainText, hashedPassword) => {
    return await bcrypt.compare(passwordPlainText, hashedPassword);
  };

  generateJwt = (payload) =>
    jwt.sign(payload, process.env.JWT_SECRET_KEY, { expiresIn: "20" });
}

module.exports = AuthService;
